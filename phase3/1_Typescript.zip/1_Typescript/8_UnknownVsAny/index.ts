/* 9) unknown vs any */

/* The core problem in plain JavaScript:
   Every single variable in JS behaves like TS's `any` type by
   default - it can hold anything, and you can call ANY
   method/property on it with zero checking, even if that method
   doesn't actually exist:

   function handle(data) {
       data.toUpperCase();   // JS: no warning even if data is a number
   }
   handle(42);   // crashes at runtime: "data.toUpperCase is not a function"

   TypeScript has TWO ways to say "I don't know the type yet":
   `any` (turns off type checking completely - dangerous, avoid it)
   `unknown` (forces me to check the type before doing anything with it) */


/* 1) any - basically opts back OUT of TypeScript entirely*/

function processAny(data: any): void {
    // TS allows ANYTHING here, no safety at all - same risk as plain JS
    console.log(data.toUpperCase()); // compiles fine even though this can crash
}
// processAny(42);   // <- compiles, but CRASHES at runtime (same bug as JS)


/* 2) unknown - the safer alternative, TS forces me to NARROW it
   before I'm allowed to use it */

function processUnknown(data: unknown): void {
    // data.toUpperCase();   // <- blocked immediately, TS refuses to compile this

    // I'm FORCED to check the type first, same idea as Topic 4 (narrowing)
    if (typeof data === "string") {
        console.log(data.toUpperCase()); // now safe, TS knows it's a string here
    } else {
        console.log("Not a string, got: " + typeof data);
    }
}


function parseUserInput(input: unknown): number {
    if (typeof input === "number") {
        return input;
    }
    if (typeof input === "string" && !isNaN(Number(input))) {
        return Number(input);
    }
    throw new Error("Invalid input - expected a number or numeric string");
}


class Example {
    static run(): void {
        console.log("\n-----unknown vs any-----");

        processAny("mangesh"); // works, but ONLY because I got lucky with input type
        processUnknown("mangesh"); // works
        processUnknown(42); // safely handled instead of crashing

        console.log("Parsed: " + parseUserInput("23"));
        console.log("Parsed: " + parseUserInput(23));

        try {
            parseUserInput("not-a-number");
        } catch (error) {
            if (error instanceof Error) {
                console.log("Caught: " + error.message);
            }
        }
    }
}

Example.run();

export {};
